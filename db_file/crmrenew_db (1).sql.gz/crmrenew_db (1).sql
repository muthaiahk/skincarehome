-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 18, 2023 at 07:57 AM
-- Server version: 5.7.23-23
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crmrenew_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appointment_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `tc_id` int(11) DEFAULT NULL,
  `date` varchar(11) DEFAULT NULL,
  `time` varchar(11) DEFAULT NULL,
  `treatment_id` int(11) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `problem` text,
  `lead_status_id` int(11) DEFAULT NULL,
  `app_status` text NOT NULL,
  `remark` text,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appointment_id`, `company_id`, `customer_id`, `lead_id`, `tc_id`, `date`, `time`, `treatment_id`, `staff_id`, `problem`, `lead_status_id`, `app_status`, `remark`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 1, 1, NULL, 1, '2023-03-11', '6:00 AM', 10, 1, NULL, 0, '1', 'Started GFC treatment', 1, '2023-03-11 06:08:01', 1, '2023-03-11 06:09:15', 0),
(2, 1, 1, NULL, 1, '2023-03-14', '4:30 PM', 10, 1, NULL, 0, '2', 'Done', 1, '2023-03-14 10:59:58', 1, '2023-03-14 11:02:58', 0);

-- --------------------------------------------------------

--
-- Table structure for table `appointment_payment`
--

CREATE TABLE `appointment_payment` (
  `app_pay_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `mode` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` int(11) NOT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `job_id` int(11) NOT NULL,
  `attendance_status` varchar(25) NOT NULL,
  `present` int(11) NOT NULL,
  `permission` int(11) NOT NULL,
  `leave` int(11) NOT NULL,
  `leave_remarks` varchar(255) DEFAULT NULL,
  `weekoff` int(11) NOT NULL,
  `from_date` datetime(6) NOT NULL,
  `to_date` datetime(6) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `modified_by` int(11) NOT NULL,
  `modified_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `branch_name` varchar(50) NOT NULL,
  `branch_location` varchar(50) NOT NULL,
  `branch_phone` varchar(50) NOT NULL,
  `branch_email` varchar(255) NOT NULL,
  `branch_authority` varchar(50) NOT NULL,
  `branch_opening_date` text NOT NULL,
  `is_franchise` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `modified_by` int(11) NOT NULL,
  `modified_on` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `status` int(11) DEFAULT '0' COMMENT '0 -> Active 1-> Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `company_id`, `branch_name`, `branch_location`, `branch_phone`, `branch_email`, `branch_authority`, `branch_opening_date`, `is_franchise`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 1, 'Renew Madurai', 'Madurai', '8056260260', 'renewplusmadurai@gmail.com', '2', '2022-11-22', 0, 1, '2022-11-21 07:14:02.755253', 1, '2023-02-20 05:05:08.551866', 0),
(2, 1, 'Renew Coimbatore', 'Coimbatore', '9875231456', 'renewcbe@gmail.com', '4', '2022-11-06', 0, 1, '2023-02-08 08:32:41.437472', 1, '2023-02-20 05:06:00.548284', 0),
(3, 1, 'Renew Plus Tirunelveli', 'Tirunelveli', '7200224589', 'renewtvl@gmail.com', '5', '2023-02-20', 0, 1, '2023-02-20 05:01:11.532131', 1, '2023-02-20 05:06:15.992520', 2),
(4, 1, 'Renew Tirunelveli', 'Tirunelveli', '9876543210', 'renewtvl@gmail.com', '2', '2022-01-01', 0, 1, '2023-02-24 07:51:48.800877', 1, '2023-02-24 07:51:48.800877', 0);

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(100) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `brand_name`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 'Sunsilk', 1, '2022-10-20 18:27:43', 1, '2023-02-22 11:32:07', 2),
(2, 'Dove1', 1, '2022-11-23 10:21:53', 1, '2023-02-22 11:32:10', 2),
(3, 'demo', 1, '2023-02-16 20:00:31', 1, '2023-02-16 20:42:20', 2),
(4, 'Tresemmee', 1, '2023-02-20 05:20:48', 1, '2023-02-20 05:21:35', 2),
(5, 'Renew', 1, '2023-02-22 11:32:21', 1, '2023-02-22 11:32:21', 0);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` datetime(6) DEFAULT CURRENT_TIMESTAMP(6),
  `updated_by` int(11) NOT NULL,
  `updated_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`company_id`, `company_name`, `created_by`, `created_on`, `updated_by`, `updated_on`) VALUES
(1, 'Renew Plus Hair and Skin', 1, '0000-00-00 00:00:00.000000', 1, '2023-02-20 04:56:01.217913');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `customer_first_name` varchar(255) NOT NULL,
  `customer_last_name` varchar(255) NOT NULL,
  `customer_dob` varchar(11) NOT NULL,
  `customer_gender` varchar(11) NOT NULL,
  `customer_age` int(11) NOT NULL,
  `customer_phone` bigint(11) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_address` text NOT NULL,
  `treatment_id` int(11) NOT NULL,
  `enquiry_date` date DEFAULT NULL,
  `lead_status_id` int(11) NOT NULL,
  `lead_source_id` int(11) NOT NULL,
  `customer_problem` varchar(255) DEFAULT NULL,
  `customer_remark` varchar(255) DEFAULT NULL,
  `sitting_count` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `branch_id`, `staff_id`, `customer_first_name`, `customer_last_name`, `customer_dob`, `customer_gender`, `customer_age`, `customer_phone`, `customer_email`, `customer_address`, `treatment_id`, `enquiry_date`, `lead_status_id`, `lead_source_id`, `customer_problem`, `customer_remark`, `sitting_count`, `state_id`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 2, 8, 'Arun', 'kumar', '1999-02-03', '1', 24, 8056931278, 'arunkumar@gmail.com', 'Peelamedu, Coimbatore', 4, '2023-02-28', 5, 3, 'Hair fall issue', NULL, 1, 23, 1, '2023-03-11 06:06:32', 1, '2023-03-11 06:06:32', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_treatment`
--

CREATE TABLE `customer_treatment` (
  `cus_treat_id` int(11) NOT NULL,
  `tc_id` int(11) NOT NULL,
  `treatment_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `progress` varchar(255) DEFAULT NULL COMMENT '0-progress 1-completed',
  `medicine_prefered` text,
  `remarks` text,
  `amount` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `generate_invoice` int(1) NOT NULL DEFAULT '0',
  `created_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` int(11) NOT NULL,
  `modified_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `modified_by` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_treatment`
--

INSERT INTO `customer_treatment` (`cus_treat_id`, `tc_id`, `treatment_id`, `customer_id`, `progress`, `medicine_prefered`, `remarks`, `amount`, `discount`, `generate_invoice`, `created_on`, `created_by`, `modified_on`, `modified_by`, `status`) VALUES
(1, 1, 10, 1, '1', NULL, 'Started the GFC treatment', 5000, 0, 0, '2023-03-11 06:07:14.836649', 1, '2023-03-14 11:02:58.400238', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `department_name` varchar(50) NOT NULL,
  `dept_incharge` varchar(50) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `company_id`, `branch_id`, `department_name`, `dept_incharge`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 1, 1, 'Consultant', NULL, 1, '2023-03-07 07:16:25', 1, '2023-03-07 07:21:50', 0),
(2, 1, 2, 'Consultant/Receptionist', NULL, 1, '2023-03-07 07:57:26', 1, '2023-03-07 07:57:52', 0),
(3, 1, 2, 'Counsellor', 'null', 1, '2023-03-07 09:04:37', 1, '2023-03-07 09:04:37', 0);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `followup_history`
--

CREATE TABLE `followup_history` (
  `followup_id` int(11) NOT NULL,
  `lead_id` int(11) NOT NULL,
  `followup_count` int(11) NOT NULL,
  `followup_date` datetime NOT NULL,
  `next_followup_date` datetime NOT NULL,
  `positive_negative_status` varchar(11) DEFAULT NULL,
  `app_status` int(11) NOT NULL DEFAULT '0',
  `remark` text,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `g_set_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `company_name` varchar(75) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `favicon` varchar(255) NOT NULL,
  `default_pic` varchar(255) NOT NULL,
  `established_date` date NOT NULL,
  `company_address` varchar(255) NOT NULL,
  `contact_person` varchar(50) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(50) NOT NULL,
  `date_format` varchar(255) NOT NULL,
  `timezone` varchar(50) NOT NULL,
  `currency` varchar(50) NOT NULL,
  `language` varchar(50) NOT NULL,
  `gst_no` varchar(20) NOT NULL,
  `pan_no` varchar(20) NOT NULL,
  `created_dt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `modified_dt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`g_set_id`, `company_id`, `company_name`, `logo`, `favicon`, `default_pic`, `established_date`, `company_address`, `contact_person`, `phone_no`, `email`, `website`, `date_format`, `timezone`, `currency`, `language`, `gst_no`, `pan_no`, `created_dt`, `modified_dt`) VALUES
(1, 1, 'Renew Plus Hair and Skin', 'https://demo.mastermart.co.in/renew_api/public/logo/22626.png', 'https://demo.mastermart.co.in/renew_api/public/favicon/22612.png', 'https://demo.mastermart.co.in/renew_api/public/default/2266.png', '2022-10-12', '', '', '9874563210', '', 'http://renewhairandskincare.com/', 'YYYY/MM/DD', 'Asia/Kolkata (UTC+05:30)', 'INR', 'English', '', '', '2022-10-20 15:38:20.389614', '2023-02-24 04:25:55.309878');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_id` int(11) NOT NULL,
  `inventory_date` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci NOT NULL,
  `company_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `prod_cat_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `stock_in_hand` int(255) NOT NULL,
  `stock_alert_count` int(255) NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `job_designation`
--

CREATE TABLE `job_designation` (
  `job_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `description` varchar(250) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_designation`
--

INSERT INTO `job_designation` (`job_id`, `company_id`, `designation`, `description`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 1, 'Cashiers', 'Cashier', 1, '2022-11-30 07:21:01.148293', 1, '2023-02-20 05:16:30.997126', 0),
(2, 1, 'Managers', 'Manager', 1, '2022-12-09 10:56:32.550930', 1, '2023-02-17 13:43:43.146625', 0),
(3, 1, 'Cashierff', NULL, 1, '2023-02-16 20:14:35.574982', 1, '2023-02-16 15:10:00.310218', 2),
(4, 1, 'Product Supplier', 'Gloves', 1, '2023-02-20 05:18:37.205902', 1, '2023-02-20 05:20:28.735614', 2),
(5, 1, 'Senior Counsellor', NULL, 1, '2023-02-24 07:53:09.282076', 1, '2023-02-24 07:53:09.282076', 0),
(6, 1, 'Staff Nurse', 'Diploma nursing assistant', 1, '2023-03-11 05:57:48.534486', 1, '2023-03-11 05:57:48.534486', 0),
(7, 1, 'Doctor', 'BDS, FACIAL AESTHITICS AND TRICHOLOGY', 1, '2023-03-11 05:58:42.380134', 1, '2023-03-11 05:58:42.380134', 0);

-- --------------------------------------------------------

--
-- Table structure for table `lead`
--

CREATE TABLE `lead` (
  `lead_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `lead_first_name` varchar(255) NOT NULL,
  `lead_last_name` varchar(255) NOT NULL,
  `lead_dob` varchar(50) NOT NULL,
  `lead_gender` varchar(10) NOT NULL,
  `lead_age` varchar(100) NOT NULL,
  `lead_phone` bigint(20) NOT NULL,
  `lead_email` varchar(255) NOT NULL,
  `lead_address` varchar(255) NOT NULL,
  `treatment_id` int(11) NOT NULL,
  `enquiry_date` varchar(11) NOT NULL,
  `lead_source_id` int(11) NOT NULL,
  `lead_status_id` int(11) NOT NULL,
  `convert_status` int(11) NOT NULL DEFAULT '0',
  `lead_problem` text,
  `lead_remark` text,
  `state_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lead`
--

INSERT INTO `lead` (`lead_id`, `company_id`, `branch_id`, `staff_id`, `lead_first_name`, `lead_last_name`, `lead_dob`, `lead_gender`, `lead_age`, `lead_phone`, `lead_email`, `lead_address`, `treatment_id`, `enquiry_date`, `lead_source_id`, `lead_status_id`, `convert_status`, `lead_problem`, `lead_remark`, `state_id`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 1, 2, 8, 'Arun', 'kumar', '1999-02-03', '1', '24', 8056931278, 'arunkumar@gmail.com', 'Peelamedu, Coimbatore', 4, '2023-02-28', 3, 5, 1, 'Hair fall issue', 'Hair fall issue and he took GFC treatment', 23, 1, '2023-03-11 06:06:32', 1, '2023-03-11 06:06:41', 0);

-- --------------------------------------------------------

--
-- Table structure for table `lead_source`
--

CREATE TABLE `lead_source` (
  `lead_source_id` int(11) NOT NULL,
  `lead_source_name` varchar(50) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lead_source`
--

INSERT INTO `lead_source` (`lead_source_id`, `lead_source_name`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 'You Tube', 1, '2023-03-07 11:31:54', 1, '2023-03-07 11:31:54', 0),
(2, 'Patient Reference', 1, '2023-03-07 11:32:10', 1, '2023-03-07 11:32:10', 0),
(3, 'Instagram', 1, '2023-03-07 11:33:19', 1, '2023-03-07 11:33:19', 0),
(4, 'Google', 1, '2023-03-07 11:33:37', 1, '2023-03-07 11:33:37', 0);

-- --------------------------------------------------------

--
-- Table structure for table `lead_status`
--

CREATE TABLE `lead_status` (
  `lead_status_id` int(11) NOT NULL,
  `lead_status_name` varchar(50) NOT NULL,
  `lead_status_description` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lead_status`
--

INSERT INTO `lead_status` (`lead_status_id`, `lead_status_name`, `lead_status_description`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 'Youtube', '', 1, '2023-03-07 11:28:25', 1, '2023-03-07 11:30:13', 2),
(2, 'Reference', '', 1, '2023-03-07 11:29:06', 1, '2023-03-07 11:30:16', 2),
(3, 'Google', '', 1, '2023-03-07 11:29:25', 1, '2023-03-07 11:30:18', 2),
(4, 'Instagram', '', 1, '2023-03-07 11:29:44', 1, '2023-03-07 11:30:20', 2),
(5, 'Positive', '', 1, '2023-03-07 11:30:36', 1, '2023-03-07 11:30:36', 0),
(6, 'Just enquiry', '', 1, '2023-03-07 11:30:55', 1, '2023-03-07 11:30:55', 0),
(7, 'Not Interested', '', 1, '2023-03-07 11:31:18', 1, '2023-03-07 11:31:18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1),
(9, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('020b6c66c1804141e377a6fe3391fac176eb8ddffba5f587b9e41abe1e3318f794021341af043fef', 1, 1, 'authToken', '[]', 1, '2023-03-07 08:34:03', '2023-03-07 09:04:08', '2024-03-07 08:34:03'),
('041b84c9805323e6356cf2c5e7f06b907be86d9e86854c1085ce817617d144fa356f8a65922db744', 1, 1, 'authToken', '[]', 0, '2023-03-11 06:31:20', '2023-03-11 06:31:20', '2024-03-11 06:31:20'),
('43d32d4fa76a276aa82724ed33e9ffe118fda58a6c5648e2c54f9c7e9375ac107d1d8ef9343177ba', 1, 1, 'authToken', '[]', 0, '2023-03-07 07:13:08', '2023-03-07 07:13:08', '2024-03-07 07:13:08'),
('516f4a93cb951bc5d17a818c42fc1a37ad2543d918a909f247fc736c8b45c1f15d0687430c9bf042', 1, 1, 'authToken', '[]', 1, '2023-03-07 07:01:38', '2023-03-07 07:32:29', '2024-03-07 07:01:38'),
('562cb0017ea3a6759352450e28eb8155afbeedd322a38bd8e6323a3a3d9565fb75ee63bcff37e5dd', 1, 1, 'authToken', '[]', 1, '2023-03-11 06:31:20', '2023-03-11 07:17:49', '2024-03-11 06:31:20'),
('56e6bba301493845a58e7eae9f79259ec7489c80b4c0c1f6bdf268499b3b70dde3313200927a9d2c', 1, 1, 'authToken', '[]', 1, '2023-03-07 07:03:00', '2023-03-07 08:23:38', '2024-03-07 07:03:00'),
('589a4f2d0dee22e7b38aebb8abcb576170fcf6bb376d9cbfac021c68773b361b88fe467e4d53db2e', 1, 1, 'authToken', '[]', 0, '2023-03-07 06:09:15', '2023-03-07 06:09:15', '2024-03-07 06:09:15'),
('67ac1d02235412b08f6ba991da62f020d7bb9369ee075ae4cc7421f2e4e47365a3fdbffb600363bc', 1, 1, 'authToken', '[]', 0, '2023-03-14 10:57:10', '2023-03-14 10:57:10', '2024-03-14 10:57:10'),
('6e1badd642c4d47445d6119283810cba9de5e0f38120c55c25995ecda63ea85a351895b07c6e2182', 1, 1, 'authToken', '[]', 0, '2023-03-11 07:17:53', '2023-03-11 07:17:53', '2024-03-11 07:17:53'),
('7b60d68ce31eabcaa1e6bc71ff53357ffe78fc43ccd93f85f1ca81a97827985bfa7c8c3c9d71f2a1', 1, 1, 'authToken', '[]', 0, '2023-03-07 11:24:06', '2023-03-07 11:24:06', '2024-03-07 11:24:06'),
('81989a37a145483dbd9c4f71342908c19df633a39539fecbf4b6e35b29c92c2401e28be9afa484a8', 1, 1, 'authToken', '[]', 1, '2023-03-11 05:48:54', '2023-03-11 07:10:43', '2024-03-11 05:48:54'),
('a35f9bf24db6bb7c4a5c0a57cf971b6adc22041cafc2f13feb7a3d3b9e15fbc7b0a048e7094cd097', 1, 1, 'authToken', '[]', 0, '2023-03-14 10:58:21', '2023-03-14 10:58:22', '2024-03-14 10:58:21'),
('a6d15f5cd8aa9bd3b4b6fc84d9b18cd6989106298ed2eb7d63ddcfbf43205371ee6170d0068598f6', 1, 1, 'authToken', '[]', 0, '2023-03-08 08:21:47', '2023-03-08 08:21:47', '2024-03-08 08:21:47'),
('c16b6fca924bdb38ed2f7b7d0ecd991170000a03173f55e1b3e8f599a8dc7a4395f9bdb046bb148d', 1, 1, 'authToken', '[]', 1, '2023-03-07 06:59:54', '2023-03-07 07:39:58', '2024-03-07 06:59:54'),
('c465c919898d9bc09a5bdc090b368af3631f0262e4f2e5b59e8ccd0cdb55c31144a44aa11c13c211', 1, 1, 'authToken', '[]', 1, '2023-03-10 09:08:56', '2023-03-11 05:48:37', '2024-03-10 09:08:56'),
('c7dbc7ff0f7d664d6c22fcc3e06ed8ca389b0f1c19f6d03046c7621de5131a24474521b6c1f9535b', 1, 1, 'authToken', '[]', 1, '2023-03-07 06:11:08', '2023-03-07 06:19:54', '2024-03-07 06:11:08'),
('cd6082285443eb93557d8f230cd2d4c2adcf53c1df87877e6e393c96318bf8437395ef0192ed7140', 1, 1, 'authToken', '[]', 0, '2023-03-14 10:58:22', '2023-03-14 10:58:22', '2024-03-14 10:58:22'),
('cefeef036f51859b66750ad04b34afcc5e70f7622d0a078df103bc10a0b34d4c9730b187c25f5267', 1, 1, 'authToken', '[]', 0, '2023-03-07 09:03:59', '2023-03-07 09:03:59', '2024-03-07 09:03:59'),
('f273c42d731b8e21579ce779b83cae6ba84157a1fc97c5154a4d27e3dc38be523bd95d871fafeb03', 1, 1, 'authToken', '[]', 1, '2023-03-07 06:47:35', '2023-03-07 08:32:24', '2024-03-07 06:47:35'),
('fb2cb47b7f955499fe61601a81fdfb06c0935bf54fbf4dbb48e588b812451c66fb51c42f6299381c', 1, 1, 'authToken', '[]', 0, '2023-03-07 07:06:28', '2023-03-07 07:06:28', '2024-03-07 07:06:28');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'XdBzq5rKpqZBgrDahVb3TWV6WzIQD1eIJj7kqAXb', NULL, 'http://localhost', 1, 0, 0, '2022-10-18 22:15:05', '2022-10-18 22:15:05'),
(2, NULL, 'Laravel Password Grant Client', 'rz9M6ZwsvQwix4aN1EyYEJIyZnmWCdaxntHQTApL', 'users', 'http://localhost', 0, 1, 0, '2022-10-18 22:15:05', '2022-10-18 22:15:05');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2022-10-18 22:15:05', '2022-10-18 22:15:05');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `p_id` int(11) NOT NULL,
  `invoice_no` varchar(11) NOT NULL,
  `cus_treat_id` int(11) NOT NULL,
  `receipt_no` varchar(11) NOT NULL,
  `payment_date` varchar(11) NOT NULL,
  `tcate_id` int(11) NOT NULL,
  `treatment_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sitting_count` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `discount` int(11) NOT NULL DEFAULT '0',
  `cgst` int(11) NOT NULL,
  `sgst` int(11) NOT NULL,
  `payment_status` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_by` int(11) NOT NULL,
  `updated_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`p_id`, `invoice_no`, `cus_treat_id`, `receipt_no`, `payment_date`, `tcate_id`, `treatment_id`, `customer_id`, `sitting_count`, `amount`, `total_amount`, `balance`, `discount`, `cgst`, `sgst`, `payment_status`, `created_by`, `created_on`, `updated_by`, `updated_on`, `status`) VALUES
(1, 'IN001/23', 1, 'RP001/23', '2023-03-14', 1, 10, 1, 1, 4500, 5000, 0, 500, 450, 450, '[{\"name\":\"cash\",\"amount\":\"4000\"},{\"name\":\"card\",\"amount\":\"500\"},{\"name\":\"cheque\",\"amount\":\"0\"},{\"name\":\"upi\",\"amount\":\"0\"}]', 1, '2023-03-14 11:02:58.399553', 1, '2023-03-14 11:02:58.399553', 0);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 1, 'authToken', 'bd60ec6c356e2bfff424ae552f26a0e37c607787f2e57f88289f106be0cdea0b', '[\"*\"]', NULL, NULL, '2022-10-26 07:03:08', '2022-10-26 07:03:08'),
(2, 'App\\Models\\User', 1, 'authToken', '8dad3cbaa43e2f7e77e4d85a0e8dfa3e165d037c75763d31cd01e053766c8c04', '[\"*\"]', NULL, NULL, '2022-10-26 07:03:29', '2022-10-26 07:03:29'),
(3, 'App\\Models\\User', 1, 'authToken', 'b239409f01eeda81b1b695b8db6082ed52ceddd528f9aa5383ad1b0cca7cef10', '[\"*\"]', NULL, NULL, '2022-10-26 07:08:13', '2022-10-26 07:08:13'),
(4, 'App\\Models\\User', 1, 'renewplus', '6bb351c1bd68cc3b5e70f49c7e72aca2e216055d05311ae0e737fa5ccf611c68', '[\"*\"]', NULL, NULL, '2022-10-26 07:37:12', '2022-10-26 07:37:12'),
(5, 'App\\Models\\User', 1, 'authToken', 'b41399418650ae8bbbf35472b3de6f99094e1a9c0bc26c3bb642c2f36142cc24', '[\"*\"]', NULL, NULL, '2022-10-26 07:37:45', '2022-10-26 07:37:45'),
(6, 'App\\Models\\User', 1, 'authToken', '1cf49dd6043121575b5a394e7f4daf12f438191c211f5384dff792805eb2d584', '[\"*\"]', NULL, NULL, '2022-10-26 07:40:05', '2022-10-26 07:40:05'),
(7, 'App\\Models\\User', 1, 'authToken', 'b4028c57b077f19ad36ea41b7a7bcfb13c2e1ef1c05d0af0f093e014bab4ef6e', '[\"*\"]', NULL, NULL, '2022-10-26 07:43:56', '2022-10-26 07:43:56'),
(8, 'App\\Models\\User', 1, 'authToken', '0197f112740dd7915c29c6219bce538b09c78d8f1e39cab0d5def740c52d69e9', '[\"*\"]', NULL, NULL, '2022-10-26 07:45:10', '2022-10-26 07:45:10');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `prod_cat_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `gst` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `prod_cat_id`, `brand_id`, `amount`, `gst`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 'Neem Face Wash', 1, 1, 10, 0, 1, '2022-10-21 14:37:33', 1, '2023-02-22 11:39:14', 2),
(2, 'Hair Sine', 1, 1, 20, 0, 1, '2022-11-30 05:20:11', 1, '2023-02-21 11:11:50', 2),
(3, 'skincario', 1, 2, 30, 0, 1, '2023-02-16 19:58:52', 1, '2023-02-21 11:11:57', 2),
(4, 'Mayuri Neem', 1, 1, 10, 0, 1, '2023-02-17 11:16:31', 1, '2023-02-22 11:39:17', 2),
(5, 'Dove Hair Fall Shampoo', 1, 2, 16, 0, 1, '2023-02-20 05:25:02', 1, '2023-02-22 11:39:19', 2),
(6, 'Dove Powder', 2, 2, 30, 0, 1, '2023-02-20 06:04:08', 1, '2023-02-22 11:39:22', 2),
(7, 'dfg', 1, 1, 50, 0, 1, '2023-02-21 10:15:04', 1, '2023-02-22 11:39:26', 2),
(8, 'Anti-Dandruff Shampoo - 100ml', 4, 5, 310, 12, 1, '2023-02-22 11:40:02', 1, '2023-03-01 04:17:59', 0),
(9, 'Bio-Tin Tablets - 1 Strip', 5, 5, 135, 18, 1, '2023-02-22 11:40:44', 1, '2023-02-28 09:59:16', 0),
(10, 'Hairfall Shampoo - 200ml', 4, 5, 600, 18, 1, '2023-02-22 11:41:26', 1, '2023-02-28 10:02:12', 0),
(11, 'Hair Serum - 60ml', 6, 5, 999, 18, 1, '2023-02-22 11:42:07', 1, '2023-02-28 10:02:47', 0),
(12, 'Grey Hair Serum - 60ml', 6, 5, 1345, 18, 1, '2023-02-22 11:42:42', 1, '2023-02-28 10:02:36', 0),
(13, 'Protein Powder - 400gm', 7, 5, 695, 18, 1, '2023-02-22 11:43:45', 1, '2023-02-28 10:02:24', 0),
(14, 'Minoxidil Spray - 60ml', 8, 5, 779, 18, 1, '2023-02-22 11:45:10', 1, '2023-02-28 10:02:03', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `prod_cat_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `prod_cat_name` varchar(100) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`prod_cat_id`, `brand_id`, `prod_cat_name`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 1, 'Shampoo', 1, '2022-10-21 15:40:35', 1, '2023-02-22 11:32:54', 2),
(2, 1, 'Powder', 1, '2023-02-16 19:56:58', 1, '2023-02-22 11:32:57', 2),
(3, 1, 'Cocunut Oil', 1, '2023-02-20 06:05:02', 1, '2023-02-20 06:05:53', 2),
(4, 5, 'Shampo', 1, '2023-02-22 11:33:32', 1, '2023-02-22 11:33:32', 0),
(5, 5, 'Tablets', 1, '2023-02-22 11:36:08', 1, '2023-02-22 11:36:08', 0),
(6, 5, 'Serum', 1, '2023-02-22 11:38:00', 1, '2023-02-22 11:38:00', 0),
(7, 5, 'Protein Powder', 1, '2023-02-22 11:38:56', 1, '2023-02-22 11:38:56', 0),
(8, 5, 'Spray', 1, '2023-02-22 11:44:18', 1, '2023-02-22 11:44:18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_on` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `created_by` int(11) NOT NULL,
  `modified_on` timestamp(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000',
  `modified_by` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role_id`, `role_name`, `role_description`, `created_on`, `created_by`, `modified_on`, `modified_by`, `status`) VALUES
(1, 'Admin', '', '2023-03-07 07:31:18.000000', 1, '2023-03-07 07:31:18.000000', 1, 0),
(2, 'Consultant', NULL, '2023-03-07 07:50:39.914819', 1, '2023-03-07 07:38:18.000000', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `role_permission`
--

CREATE TABLE `role_permission` (
  `rp_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `page` text COLLATE utf8_unicode_ci NOT NULL,
  `permission` text COLLATE utf8_unicode_ci,
  `created_at` timestamp(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `role_permission`
--

INSERT INTO `role_permission` (`rp_id`, `role_id`, `page`, `permission`, `created_at`, `created_by`, `updated_at`, `updated_by`, `status`) VALUES
(1, 1, 'dashboard', 'view', '2023-03-07 06:58:04.128638', 1, '2023-03-07 06:58:04', 1, 0),
(2, 1, 'lead', 'add,edit,view,delete', '2023-03-07 06:58:04.130447', 1, '2023-03-07 06:58:04', 1, 0),
(3, 1, 'customer', 'add,edit,view,delete', '2023-03-07 06:58:04.131144', 1, '2023-03-07 06:58:04', 1, 0),
(4, 1, 'appointment', 'add,edit,view,delete', '2023-03-07 06:58:04.131759', 1, '2023-03-07 06:58:04', 1, 0),
(5, 1, 'staff', 'add,edit,view,delete', '2023-03-07 06:58:04.132381', 1, '2023-03-07 06:58:04', 1, 0),
(6, 1, 'treatment', 'add,edit,view,delete', '2023-03-07 06:58:04.132995', 1, '2023-03-07 06:58:04', 1, 0),
(7, 1, 'payment', 'add,edit,view,delete', '2023-03-07 06:58:04.133580', 1, '2023-03-07 06:58:04', 1, 0),
(8, 1, 'inventory', 'add,edit,view,delete', '2023-03-07 06:58:04.134202', 1, '2023-03-07 06:58:04', 1, 0),
(9, 1, 'lead_rpt', 'view', '2023-03-07 06:58:04.134799', 1, '2023-03-07 06:58:04', 1, 0),
(10, 1, 'stock_rpt', 'view', '2023-03-07 06:58:04.135371', 1, '2023-03-07 06:58:04', 1, 0),
(11, 1, 'attendance_rpt', 'view', '2023-03-07 06:58:04.135971', 1, '2023-03-07 06:58:04', 1, 0),
(12, 1, 'payment_rpt', 'view', '2023-03-07 06:58:04.136547', 1, '2023-03-07 06:58:04', 1, 0),
(13, 3, 'dashboard', 'view', '2023-02-21 11:21:34.026057', 1, '2023-02-21 11:21:34', 1, 0),
(14, 3, 'lead', NULL, '2023-02-21 11:21:34.027674', 1, '2023-02-21 11:21:34', 1, 0),
(15, 3, 'customer', NULL, '2023-02-21 11:21:34.028333', 1, '2023-02-21 11:21:34', 1, 0),
(16, 3, 'appointment', NULL, '2023-02-21 11:21:34.029017', 1, '2023-02-21 11:21:34', 1, 0),
(17, 3, 'staff', 'add,edit,view', '2023-02-21 11:21:34.029621', 1, '2023-02-21 11:21:34', 1, 0),
(18, 3, 'treament', '', '2023-01-25 03:16:52.660075', 1, '2023-01-25 03:16:52', 1, 0),
(19, 3, 'payment', NULL, '2023-02-21 11:21:34.030806', 1, '2023-02-21 11:21:34', 1, 0),
(20, 3, 'inventory', NULL, '2023-02-21 11:21:34.031358', 1, '2023-02-21 11:21:34', 1, 0),
(21, 3, 'lead_rpt', NULL, '2023-02-21 11:21:34.031892', 1, '2023-02-21 11:21:34', 1, 0),
(22, 3, 'stock_rpt', NULL, '2023-02-21 11:21:34.032434', 1, '2023-02-21 11:21:34', 1, 0),
(23, 3, 'attendance_rpt', NULL, '2023-02-21 11:21:34.032971', 1, '2023-02-21 11:21:34', 1, 0),
(24, 3, 'payment_rpt', NULL, '2023-02-21 11:21:34.033520', 1, '2023-02-21 11:21:34', 1, 0),
(25, 1, 'settings', '[{\"name\":\"general_setting\",\"permission\":[\"view\",\"delete\",\"add\",\"edit\"]},{\"name\":\"email_setting\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"company\",\"permission\":[\"edit\"]},{\"name\":\"branch\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"department\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"designation\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"brand\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"lead_source\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"lead_status\",\"permission\":[\"add\",\"edit\",\"delete\",\"view\"]},{\"name\":\"product\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"product_category\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"treatment\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"treatment_category\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"role\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]}]', '2023-03-07 06:58:04.137178', 1, '2023-03-07 06:58:04', 1, 0),
(26, 4, 'dashboard', 'view', '2023-02-16 14:19:51.463943', 1, '2023-02-16 14:19:51', 1, 0),
(27, 4, 'lead', 'add,edit,view,delete', '2023-02-16 14:19:51.500525', 1, '2023-02-16 14:19:51', 1, 0),
(28, 4, 'customer', 'add,edit,view,delete', '2023-02-16 14:19:51.518111', 1, '2023-02-16 14:19:51', 1, 0),
(29, 4, 'appointment', 'add,edit,view,delete', '2023-02-16 14:19:51.546669', 1, '2023-02-16 14:19:51', 1, 0),
(30, 4, 'staff', NULL, '2023-02-16 14:19:51.558997', 1, '2023-02-16 14:19:51', 1, 0),
(31, 4, 'treatment', 'add,view', '2023-02-16 14:19:51.573480', 1, '2023-02-16 14:19:51', 1, 0),
(32, 4, 'payment', 'add,edit,view,delete', '2023-02-16 14:19:51.587170', 1, '2023-02-16 14:19:51', 1, 0),
(33, 4, 'inventory', 'add,edit,view,delete', '2023-02-16 14:19:51.622966', 1, '2023-02-16 14:19:51', 1, 0),
(34, 4, 'lead_rpt', NULL, '2023-02-16 14:19:51.643385', 1, '2023-02-16 14:19:51', 1, 0),
(35, 4, 'stock_rpt', NULL, '2023-02-16 14:19:51.656002', 1, '2023-02-16 14:19:51', 1, 0),
(36, 4, 'attendance_rpt', NULL, '2023-02-16 14:19:51.672077', 1, '2023-02-16 14:19:51', 1, 0),
(37, 4, 'payment_rpt', NULL, '2023-02-16 14:19:51.690342', 1, '2023-02-16 14:19:51', 1, 0),
(38, 4, 'settings', '[{\"name\":\"general_setting\",\"permission\":[]},{\"name\":\"email_setting\",\"permission\":[]},{\"name\":\"company\",\"permission\":[]},{\"name\":\"branch\",\"permission\":[]},{\"name\":\"department\",\"permission\":[]},{\"name\":\"designation\",\"permission\":[]},{\"name\":\"brand\",\"permission\":[\"add\",\"delete\",\"view\",\"edit\"]},{\"name\":\"lead_source\",\"permission\":[\"add\",\"delete\",\"edit\",\"view\"]},{\"name\":\"lead_status\",\"permission\":[\"add\",\"delete\",\"edit\",\"view\"]},{\"name\":\"product\",\"permission\":[\"add\",\"delete\",\"edit\",\"view\"]},{\"name\":\"product_category\",\"permission\":[\"add\",\"delete\",\"edit\",\"view\"]},{\"name\":\"treatment\",\"permission\":[\"add\",\"delete\",\"edit\",\"view\"]},{\"name\":\"treatment_category\",\"permission\":[\"add\",\"edit\",\"view\",\"delete\"]},{\"name\":\"role\",\"permission\":[]}]', '2023-02-16 14:19:51.710458', 1, '2023-02-16 14:19:51', 1, 0),
(39, 3, 'treatment', NULL, '2023-02-21 11:21:34.030241', 1, '2023-02-21 11:21:34', 1, 0),
(40, 3, 'settings', '[{\"name\":\"general_setting\",\"permission\":[]},{\"name\":\"email_setting\",\"permission\":[]},{\"name\":\"company\",\"permission\":[]},{\"name\":\"branch\",\"permission\":[]},{\"name\":\"department\",\"permission\":[]},{\"name\":\"designation\",\"permission\":[]},{\"name\":\"brand\",\"permission\":[]},{\"name\":\"lead_source\",\"permission\":[]},{\"name\":\"lead_status\",\"permission\":[]},{\"name\":\"product\",\"permission\":[]},{\"name\":\"product_category\",\"permission\":[]},{\"name\":\"treatment\",\"permission\":[]},{\"name\":\"treatment_category\",\"permission\":[]},{\"name\":\"role\",\"permission\":[]}]', '2023-02-21 11:21:34.034096', 1, '2023-02-21 11:21:34', 1, 0),
(41, 5, 'dashboard', 'view', '2023-02-17 04:52:56.096322', 1, '2023-02-17 04:52:56', 1, 0),
(42, 5, 'lead', 'add,edit', '2023-02-17 04:52:56.098131', 1, '2023-02-17 04:52:56', 1, 0),
(43, 5, 'customer', NULL, '2023-02-17 04:52:56.098928', 1, '2023-02-17 04:52:56', 1, 0),
(44, 5, 'appointment', NULL, '2023-02-17 04:52:56.099635', 1, '2023-02-17 04:52:56', 1, 0),
(45, 5, 'staff', NULL, '2023-02-17 04:52:56.100243', 1, '2023-02-17 04:52:56', 1, 0),
(46, 5, 'treatment', NULL, '2023-02-17 04:52:56.100878', 1, '2023-02-17 04:52:56', 1, 0),
(47, 5, 'payment', NULL, '2023-02-17 04:52:56.101466', 1, '2023-02-17 04:52:56', 1, 0),
(48, 5, 'inventory', NULL, '2023-02-17 04:52:56.102114', 1, '2023-02-17 04:52:56', 1, 0),
(49, 5, 'lead_rpt', NULL, '2023-02-17 04:52:56.102826', 1, '2023-02-17 04:52:56', 1, 0),
(50, 5, 'stock_rpt', NULL, '2023-02-17 04:52:56.103424', 1, '2023-02-17 04:52:56', 1, 0),
(51, 5, 'attendance_rpt', NULL, '2023-02-17 04:52:56.103997', 1, '2023-02-17 04:52:56', 1, 0),
(52, 5, 'payment_rpt', NULL, '2023-02-17 04:52:56.104591', 1, '2023-02-17 04:52:56', 1, 0),
(53, 5, 'settings', '[{\"name\":\"general_setting\",\"permission\":[]},{\"name\":\"email_setting\",\"permission\":[]},{\"name\":\"company\",\"permission\":[]},{\"name\":\"branch\",\"permission\":[]},{\"name\":\"department\",\"permission\":[]},{\"name\":\"designation\",\"permission\":[]},{\"name\":\"brand\",\"permission\":[]},{\"name\":\"lead_source\",\"permission\":[]},{\"name\":\"lead_status\",\"permission\":[]},{\"name\":\"product\",\"permission\":[]},{\"name\":\"product_category\",\"permission\":[]},{\"name\":\"treatment\",\"permission\":[]},{\"name\":\"treatment_category\",\"permission\":[]},{\"name\":\"role\",\"permission\":[]}]', '2023-02-17 04:52:56.105176', 1, '2023-02-17 04:52:56', 1, 0),
(54, 6, 'dashboard', 'view', '2023-02-17 12:24:31.565755', 1, '2023-02-17 12:24:31', 1, 0),
(55, 6, 'lead', 'add,edit,view', '2023-02-17 12:24:31.567399', 1, '2023-02-17 12:24:31', 1, 0),
(56, 6, 'customer', 'add,edit', '2023-02-17 12:24:31.568045', 1, '2023-02-17 12:24:31', 1, 0),
(57, 6, 'appointment', NULL, '2023-02-17 12:24:31.568686', 1, '2023-02-17 12:24:31', 1, 0),
(58, 6, 'staff', NULL, '2023-02-17 12:24:31.569324', 1, '2023-02-17 12:24:31', 1, 0),
(59, 6, 'treatment', NULL, '2023-02-17 12:24:31.569943', 1, '2023-02-17 12:24:31', 1, 0),
(60, 6, 'payment', NULL, '2023-02-17 12:24:31.570518', 1, '2023-02-17 12:24:31', 1, 0),
(61, 6, 'inventory', NULL, '2023-02-17 12:24:31.571093', 1, '2023-02-17 12:24:31', 1, 0),
(62, 6, 'lead_rpt', NULL, '2023-02-17 12:24:31.571713', 1, '2023-02-17 12:24:31', 1, 0),
(63, 6, 'stock_rpt', NULL, '2023-02-17 12:24:31.572303', 1, '2023-02-17 12:24:31', 1, 0),
(64, 6, 'attendance_rpt', NULL, '2023-02-17 12:24:31.572893', 1, '2023-02-17 12:24:31', 1, 0),
(65, 6, 'payment_rpt', NULL, '2023-02-17 12:24:31.573464', 1, '2023-02-17 12:24:31', 1, 0),
(66, 6, 'settings', '[{\"name\":\"general_setting\",\"permission\":[]},{\"name\":\"email_setting\",\"permission\":[]},{\"name\":\"company\",\"permission\":[]},{\"name\":\"branch\",\"permission\":[]},{\"name\":\"department\",\"permission\":[]},{\"name\":\"designation\",\"permission\":[]},{\"name\":\"brand\",\"permission\":[]},{\"name\":\"lead_source\",\"permission\":[]},{\"name\":\"lead_status\",\"permission\":[]},{\"name\":\"product\",\"permission\":[]},{\"name\":\"product_category\",\"permission\":[]},{\"name\":\"treatment\",\"permission\":[]},{\"name\":\"treatment_category\",\"permission\":[]},{\"name\":\"role\",\"permission\":[]}]', '2023-02-17 12:24:31.574065', 1, '2023-02-17 12:24:31', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `prod_cat_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `emergency_contact` bigint(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `date_of_birth` varchar(255) NOT NULL,
  `date_of_joining` varchar(255) NOT NULL,
  `salary` int(11) DEFAULT NULL,
  `gender` varchar(11) NOT NULL,
  `marital_status` varchar(11) DEFAULT NULL,
  `date_of_relieve` varchar(255) DEFAULT NULL,
  `dept_id` int(11) NOT NULL DEFAULT '0',
  `role_id` int(11) NOT NULL DEFAULT '0',
  `job_id` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `company_id`, `branch_id`, `name`, `address`, `phone_no`, `emergency_contact`, `email`, `date_of_birth`, `date_of_joining`, `salary`, `gender`, `marital_status`, `date_of_relieve`, `dept_id`, `role_id`, `job_id`, `username`, `password`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 1, 1, 'admin', 'madurai', '9874563210', 9874563210, 'admin@gmail.com', '', '', NULL, 'male', 'married', NULL, 4, 1, 1, 'admin', '', 0, '0000-00-00 00:00:00.000000', 1, '2023-02-23 09:18:14.775967', 0),
(2, 1, 1, 'Mahesh', 'Madurai', '9874563218', 9856321047, 'demo@gmail.com', '1999-01-30', '2022-11-22', NULL, 'male', NULL, NULL, 4, 3, 1, 'demo', 'demo@123', 0, '2022-11-30 08:05:26.542266', 1, '2023-02-23 09:21:57.116641', 0),
(4, 1, 1, 'Lokesh', '2/39 4th st,ranganathapuram,west tambaram', '8056260260', 9080086365, 'logesh267@gmail.com', '1991-04-16', '2021-08-21', NULL, 'male', NULL, NULL, 5, 1, 2, 'admin', 'demo@123', 0, '2022-12-09 11:02:33.113836', 1, '2023-02-23 09:22:18.255847', 0),
(5, 1, 1, 'Mohan', 'Madurai', '8795426458', 87594265878, 'mohan@gmail.com', '1998-02-24', '2023-01-24', NULL, 'male', NULL, NULL, 4, 3, 2, 'Mohan', '', 0, '2023-01-24 07:33:37.351204', 0, '2023-02-23 09:18:01.884024', 0),
(6, 1, 1, 'Himesh', 'Madurai', '7200229315', 8667848520, 'himesh@gmail.com', '2003-02-21', '2023-02-21', NULL, 'male', NULL, NULL, 4, 3, 2, 'himesh', '', 1, '2023-02-21 11:25:08.132589', 1, '2023-02-23 09:18:08.705949', 0),
(7, 1, 1, 'Lokesh Bala', '2/39 4th st,ranganathapuram,west tambaram', '8056260260', 9080086365, 'logesh267@gmail.com', '1991-04-16', '2021-08-20', NULL, '0', NULL, NULL, 1, 0, 2, 'admin', 'admin@123', 1, '2023-03-07 11:39:19.481993', 1, '2023-03-07 11:39:19.481993', 0),
(8, 1, 2, 'Keerthi', 'Coimbatore', '8248646238', 9094290805, 'keerthigarrk@gmail.com', '1997-07-11', '2022-11-03', NULL, 'female', NULL, NULL, 2, 2, 2, 'admin', 'admin@123', 1, '2023-03-11 05:50:14.996061', 1, '2023-03-11 05:50:14.996061', 0),
(9, 1, 4, 'Malar sangeetha', 'no109,c/1 north bypass road,vannarapettai bazaar, tirunelveli-627003', '9791221232', 9791221232, 'malarsangeetha10@gmail.com', '1999-08-27', '2022-01-27', NULL, 'female', NULL, NULL, 2, 2, 1, 'admin', 'admin@123', 1, '2023-03-11 07:23:32.380653', 1, '2023-03-11 07:23:55.201236', 2),
(10, 1, 4, 'Malar sangeetha', 'no109,c/1 north bypass road,vannarapettai bazaar, tirunelveli-627003', '9791221232', 9791221232, 'malarsangeetha10@gmail.com', '1999-08-27', '2022-01-27', NULL, 'female', NULL, NULL, 2, 2, 1, 'admin', 'admin@123', 1, '2023-03-11 07:23:35.222710', 1, '2023-03-11 07:23:35.222710', 0),
(11, 1, 4, 'Subbu lakshmi', 'no109,c/1 north bypass road,vannarapettai bazaar, tirunelveli-627003', '6369375981', 6369375981, 'iyyapanmani3@gmail.com', '1996-10-16', '2022-01-24', NULL, 'female', NULL, NULL, 0, 2, 6, 'admin', 'admin@123', 1, '2023-03-11 07:28:05.490696', 1, '2023-03-11 07:28:05.490696', 0);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `state_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `modified_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`state_id`, `name`, `created_by`, `modified_by`, `created_at`, `modified_at`) VALUES
(1, 'Andhra Pradesh', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(2, 'Arunachal Pradesh', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(3, 'Assam', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(4, 'Bihar', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(5, 'Chhattisgarh', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(6, 'Goa', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(7, 'Gujarat', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(8, 'Haryana', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(9, 'Himachal Pradesh', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(10, 'Jharkhand', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(11, 'Karnataka', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(12, 'Kerala', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(13, 'Madhya Pradesh', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(14, 'Maharashtra', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(15, 'Manipur', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(16, 'Meghalaya', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(17, 'Mizoram', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(18, 'Nagaland', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(19, 'Odisha', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(20, 'Punjab', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(21, 'Rajasthan', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(22, 'Sikkim', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(23, 'Tamil Nadu', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(24, 'Telangana', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(25, 'Tripura', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(26, 'Uttar Pradesh', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(27, 'Uttarakhand', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000'),
(28, 'West Bengal', 1, 1, '0000-00-00 00:00:00.000000', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `stock_maintanance`
--

CREATE TABLE `stock_maintanance` (
  `stock_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `prod_cat_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `stock_in_hand` int(255) NOT NULL,
  `stock_out` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL,
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `treatment_id` int(11) NOT NULL,
  `tc_id` int(11) NOT NULL,
  `treatment_name` varchar(50) NOT NULL,
  `treatment_description` varchar(255) DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`treatment_id`, `tc_id`, `treatment_name`, `treatment_description`, `amount`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 1, 'Hair Transplant', NULL, 50000, 1, '2022-12-07 09:55:25', 1, '2023-02-24 04:52:57', 2),
(2, 2, 'Cosmetic Skin Treatment', NULL, 30000, 1, '2023-01-31 14:29:39', 1, '2023-02-24 04:52:59', 2),
(3, 1, 'GFC', NULL, 5000, 1, '2023-02-08 04:56:40', 1, '2023-02-24 04:53:02', 2),
(4, 1, 'Dandruff Treatment', NULL, 15000, 1, '2023-02-20 05:29:54', 1, '2023-02-24 04:53:04', 2),
(10, 1, 'GFC - Grow Factor Concentrate Treatment', NULL, 5000, 1, '2023-02-24 04:54:07', 1, '2023-02-24 04:59:12', 0),
(11, 1, 'PRP - Platelet Rich Plasma Treatment', NULL, 2500, 1, '2023-02-24 04:55:14', 1, '2023-02-24 04:55:14', 0),
(12, 1, 'FUE - Follicular Unit Extraction Treatment', NULL, 25000, 1, '2023-02-24 04:56:57', 1, '2023-02-24 04:59:32', 0),
(13, 1, 'Bio-FUE Treatment', NULL, 35000, 1, '2023-02-24 04:57:55', 1, '2023-02-24 04:58:10', 0),
(14, 1, 'Bio-GFC Treatment', NULL, 45000, 1, '2023-02-24 04:58:46', 1, '2023-02-24 04:58:46', 0);

-- --------------------------------------------------------

--
-- Table structure for table `treatment_category`
--

CREATE TABLE `treatment_category` (
  `tcategory_id` int(11) NOT NULL,
  `tc_name` varchar(50) NOT NULL,
  `tc_description` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `treatment_category`
--

INSERT INTO `treatment_category` (`tcategory_id`, `tc_name`, `tc_description`, `created_by`, `created_on`, `modified_by`, `modified_on`, `status`) VALUES
(1, 'Hair treatment', NULL, 1, '2022-10-21 16:18:39', 1, '2022-11-08 14:33:58', 0),
(2, 'Skin', NULL, 1, '2022-12-01 09:24:41', 1, '2023-02-20 05:31:01', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `staff_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `staff_id`, `company_id`, `role_id`, `username`, `password`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 'admin', '$2y$10$pU3TM6biByukN.5bJvhcH.UnUspO.MOLuxw9tXyqR.Zh4z1u9bR9q', '2022-10-26 02:32:04', '2022-10-26 02:32:04'),
(2, 2, 1, 3, 'demo', '$2y$10$ZgTCa2XOKg9LqpI6yg.fW.Oy4r9R1SMIsYWmO3AV2bp7Ui9q80er.', '2022-11-30 08:05:26', '2023-02-23 09:21:57'),
(3, 4, 1, 1, 'admin', '$2y$10$Jqx9babDeVqXnFKnF3hS1.fa3OrvP6m7sebFVsGIecSIGvx0HB.Ga', '2022-12-09 11:02:33', '2023-02-23 09:22:18'),
(4, 5, 1, 3, 'Mohan', '$2y$10$G1XkOiAjq.zA19Jm0XNZmOIK6ePlrwwHCUz5zcWLWKoVmSXhKWAky', '2023-01-24 07:33:37', '2023-01-24 07:33:37'),
(5, 6, 1, 3, 'himesh', '$2y$10$tM.bUCNwEvfh83p6idlQAudGZFKnObmjdq6ETWCYOvtL/OqeD5PTq', '2023-02-21 11:25:08', '2023-02-21 11:25:08'),
(6, 7, 1, 0, 'admin', '$2y$10$xcKK4RTzaC5Vnc4ag8Ny6OwFSedrHp0NGWjs91MnhqYxS4R3E0NzK', '2023-03-07 11:39:19', '2023-03-07 11:39:19'),
(7, 8, 1, 2, 'admin', '$2y$10$pEcZ/.ttaVt4sKisDAD5/.1ONdOaf0vwYYAi1Te2nXXE4c.Z/.Hlq', '2023-03-11 05:50:15', '2023-03-11 05:50:15'),
(8, 9, 1, 2, 'admin', '$2y$10$s/mzD8hJDGjVrvN9fXKuTOAwc6THRakSOjOlyTKHv14sAdbByFe9u', '2023-03-11 07:23:32', '2023-03-11 07:23:32'),
(9, 10, 1, 2, 'admin', '$2y$10$w3JXXSD4njS4MV8VQLcjseBJI..IP2zrJHeRHm1KkZwofGOeNTM9u', '2023-03-11 07:23:35', '2023-03-11 07:23:35'),
(10, 11, 1, 2, 'admin', '$2y$10$pk4F4g7DXdWFHrHOygF2MukB5kOMXA4oFqAuOdFbg74cjjLP3ijSK', '2023-03-11 07:28:05', '2023-03-11 07:28:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `fk_app_company` (`company_id`),
  ADD KEY `fk_app_customer` (`customer_id`);

--
-- Indexes for table `appointment_payment`
--
ALTER TABLE `appointment_payment`
  ADD PRIMARY KEY (`app_pay_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`),
  ADD KEY `fk_cid` (`company_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_treatment`
--
ALTER TABLE `customer_treatment`
  ADD PRIMARY KEY (`cus_treat_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`),
  ADD KEY `fk_dept_company` (`company_id`),
  ADD KEY `fk_dept_branch` (`branch_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `followup_history`
--
ALTER TABLE `followup_history`
  ADD PRIMARY KEY (`followup_id`),
  ADD KEY `fk_followup_lead` (`lead_id`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`g_set_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_id`);

--
-- Indexes for table `job_designation`
--
ALTER TABLE `job_designation`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `lead`
--
ALTER TABLE `lead`
  ADD PRIMARY KEY (`lead_id`);

--
-- Indexes for table `lead_source`
--
ALTER TABLE `lead_source`
  ADD PRIMARY KEY (`lead_source_id`);

--
-- Indexes for table `lead_status`
--
ALTER TABLE `lead_status`
  ADD PRIMARY KEY (`lead_status_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`prod_cat_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `role_permission`
--
ALTER TABLE `role_permission`
  ADD PRIMARY KEY (`rp_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `stock_maintanance`
--
ALTER TABLE `stock_maintanance`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `treatment`
--
ALTER TABLE `treatment`
  ADD PRIMARY KEY (`treatment_id`);

--
-- Indexes for table `treatment_category`
--
ALTER TABLE `treatment_category`
  ADD PRIMARY KEY (`tcategory_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appointment_payment`
--
ALTER TABLE `appointment_payment`
  MODIFY `app_pay_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer_treatment`
--
ALTER TABLE `customer_treatment`
  MODIFY `cus_treat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `followup_history`
--
ALTER TABLE `followup_history`
  MODIFY `followup_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `g_set_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventory_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_designation`
--
ALTER TABLE `job_designation`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lead`
--
ALTER TABLE `lead`
  MODIFY `lead_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lead_source`
--
ALTER TABLE `lead_source`
  MODIFY `lead_source_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lead_status`
--
ALTER TABLE `lead_status`
  MODIFY `lead_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `prod_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `role_permission`
--
ALTER TABLE `role_permission`
  MODIFY `rp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `stock_maintanance`
--
ALTER TABLE `stock_maintanance`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `treatment`
--
ALTER TABLE `treatment`
  MODIFY `treatment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `treatment_category`
--
ALTER TABLE `treatment_category`
  MODIFY `tcategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
